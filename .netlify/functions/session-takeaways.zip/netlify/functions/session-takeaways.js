var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/session-takeaways.ts
var session_takeaways_exports = {};
__export(session_takeaways_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(session_takeaways_exports);
var SYSTEM_PROMPT = `You are a UK clinician-tutor. Distil the student's misses into 2-4 ultra-short memory rules.

Output STRICT JSON: { "bullets": ["\u2026", "\u2026"] }

Rules for each bullet:
- MAX 12 words. Telegraph style \u2014 no filler words.
- Pattern \u2192 rule format. Examples:
  - "Unilateral leg weakness + sensory loss = cord, not stroke"
  - "Orthostatic hypotension + fixed HR = autonomic failure"
  - "HbA1c very high + long T2DM \u2192 start basal-bolus insulin"
  - "Dyspnoea + mid-systolic murmur increases on expiration = HOCM"
  - "Age <55 non-Black \u2192 ACEi first; >55 or Black \u2192 CCB"
- One rule per clinical pattern. Group related misses.
- All-correct: ONE bullet = next topic to drill.
- NO full sentences. NO conjunctions like "which" or "that".

Return JSON ONLY.`;
var userPrompt = (wrong, right) => {
  const wrongLines = wrong.length === 0 ? "(none \u2014 all correct)" : wrong.map((w, i) => `${i + 1}. [${(w.topicPath ?? []).join(" > ")}] ${w.stem}
   Correct answer: ${w.answer}`).join("\n");
  const summary = `Session: ${right.length} correct, ${wrong.length} wrong.`;
  return `${summary}

Wrong picks:
${wrongLines}

Write the JSON takeaways.`;
};
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }
  let parsed;
  try {
    parsed = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "invalid json" }) };
  }
  const wrong = parsed.wrong ?? [];
  const right = parsed.right ?? [];
  if (!Array.isArray(wrong) || !Array.isArray(right)) {
    return { statusCode: 400, body: JSON.stringify({ error: "wrong/right must be arrays" }) };
  }
  if (wrong.length + right.length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: "empty session" }) };
  }
  const openaiKey = process.env.OPENAI_TTS_KEY;
  const deepseekKey = process.env.VITE_OPENAI_API_KEY;
  const provider = openaiKey ? { url: "https://api.openai.com/v1/chat/completions", key: openaiKey, model: "gpt-4o-mini" } : deepseekKey ? { url: "https://api.deepseek.com/chat/completions", key: deepseekKey, model: "deepseek-chat" } : null;
  if (!provider) {
    return { statusCode: 503, body: JSON.stringify({ error: "no llm key configured" }) };
  }
  try {
    const response = await fetch(provider.url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${provider.key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: provider.model,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: userPrompt(wrong.slice(0, 20), right.slice(0, 20)) }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4
      })
    });
    if (!response.ok) {
      const err = await response.text().catch(() => "");
      console.error("upstream", response.status, err.slice(0, 200));
      return { statusCode: 502, body: JSON.stringify({ error: "upstream_failed" }) };
    }
    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) {
      return { statusCode: 502, body: JSON.stringify({ error: "empty content" }) };
    }
    let parsedContent;
    try {
      parsedContent = JSON.parse(content);
    } catch {
      return { statusCode: 502, body: JSON.stringify({ error: "bad json from llm" }) };
    }
    const bullets = parsedContent?.bullets;
    if (!Array.isArray(bullets) || bullets.length === 0) {
      return { statusCode: 502, body: JSON.stringify({ error: "no bullets" }) };
    }
    const cleaned = bullets.filter((b) => typeof b === "string").map((b) => b.trim().slice(0, 280)).filter((b) => b.length > 10).slice(0, 5);
    if (cleaned.length === 0) {
      return { statusCode: 502, body: JSON.stringify({ error: "all bullets invalid" }) };
    }
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
      body: JSON.stringify({ bullets: cleaned })
    };
  } catch (err) {
    console.error("takeaways function error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: "function_failed" }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
