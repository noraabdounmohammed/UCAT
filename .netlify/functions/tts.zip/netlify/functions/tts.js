var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/tts.ts
var tts_exports = {};
__export(tts_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(tts_exports);
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }
  const apiKey = process.env.OPENAI_TTS_KEY;
  if (!apiKey) {
    return {
      statusCode: 503,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        error: "tts_not_configured",
        message: "Set OPENAI_TTS_KEY in Netlify env to enable studio-quality TTS."
      })
    };
  }
  let text;
  let voice;
  try {
    const parsed = JSON.parse(event.body || "{}");
    text = String(parsed.text ?? "").trim();
    voice = String(parsed.voice ?? "nova");
    if (!text) {
      return { statusCode: 400, body: JSON.stringify({ error: "text required" }) };
    }
    if (text.length > 4096) {
      return { statusCode: 400, body: JSON.stringify({ error: "text too long (max 4096 chars)" }) };
    }
    const allowed = /* @__PURE__ */ new Set(["alloy", "echo", "fable", "onyx", "nova", "shimmer"]);
    if (!allowed.has(voice)) voice = "nova";
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "invalid json" }) };
  }
  try {
    const response = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "tts-1",
        voice,
        input: text,
        response_format: "mp3"
      })
    });
    if (!response.ok) {
      const errBody = await response.text().catch(() => "");
      console.error("OpenAI TTS error:", response.status, errBody.slice(0, 200));
      return {
        statusCode: 502,
        body: JSON.stringify({ error: "upstream_failed", upstreamStatus: response.status })
      };
    }
    const audioBuf = Buffer.from(await response.arrayBuffer());
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "audio/mpeg",
        // Cache aggressively — same text + voice always yields the same audio.
        // 1 day is plenty since stems are immutable once approved.
        "Cache-Control": "public, max-age=86400, immutable"
      },
      body: audioBuf.toString("base64"),
      isBase64Encoded: true
    };
  } catch (err) {
    console.error("tts function error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "tts_function_failed", message: String(err) })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
