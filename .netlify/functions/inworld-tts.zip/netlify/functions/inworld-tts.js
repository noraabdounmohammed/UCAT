var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/inworld-tts.ts
var inworld_tts_exports = {};
__export(inworld_tts_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(inworld_tts_exports);
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const apiKey = process.env.VITE_INWORLD_API_KEY;
    const apiSecret = process.env.VITE_INWORLD_API_SECRET;
    if (!apiKey) {
      return {
        statusCode: 500,
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Inworld API key not configured" })
      };
    }
    let authValue;
    if (apiSecret) {
      authValue = Buffer.from(`${apiKey}:${apiSecret}`).toString("base64");
    } else {
      authValue = apiKey;
    }
    const body = event.body ? JSON.parse(event.body) : {};
    const ttsResponse = await fetch("https://api.inworld.ai/tts/v1/voice:stream", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${authValue}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        text: body.text || "",
        voiceId: body.voiceId || "Ashley",
        modelId: body.modelId || "inworld-tts-1.5-max",
        audio_config: body.audio_config || {
          audio_encoding: "MP3"
        }
      })
    });
    if (!ttsResponse.ok) {
      const errorText = await ttsResponse.text();
      console.error("Inworld TTS error:", ttsResponse.status, errorText);
      return {
        statusCode: ttsResponse.status,
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify({ error: `TTS failed: ${ttsResponse.status}`, details: errorText })
      };
    }
    const responseText = await ttsResponse.text();
    return {
      statusCode: 200,
      headers: { ...headers, "Content-Type": "application/x-ndjson" },
      body: responseText
    };
  } catch (error) {
    console.error("TTS proxy error:", error);
    return {
      statusCode: 500,
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "TTS proxy failed" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
