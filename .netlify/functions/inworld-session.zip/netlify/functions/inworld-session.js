var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/inworld-session.ts
var inworld_session_exports = {};
__export(inworld_session_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(inworld_session_exports);
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const apiKey = process.env.VITE_INWORLD_API_KEY;
    const apiSecret = process.env.VITE_INWORLD_API_SECRET;
    if (!apiKey || !apiSecret) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Inworld credentials not configured" })
      };
    }
    const credentials = Buffer.from(`${apiKey}:${apiSecret}`).toString("base64");
    const response = await fetch("https://api.inworld.ai/v1/session/open", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${credentials}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        // Session configuration
        capabilities: {
          audio: true,
          text: true,
          emotions: true,
          interruptions: true
        }
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Inworld session error:", errorText);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ error: `Inworld API error: ${response.status}` })
      };
    }
    const sessionData = await response.json();
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        sessionId: sessionData.sessionId || sessionData.session_id,
        token: sessionData.token || sessionData.accessToken,
        wsUrl: sessionData.wsUrl || "wss://api.inworld.ai/v1/session/stream"
      })
    };
  } catch (error) {
    console.error("Session creation error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "Failed to create session" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
